#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void) {
  printf("%ld\n", sizeof(time_t));
  return 0;
}

